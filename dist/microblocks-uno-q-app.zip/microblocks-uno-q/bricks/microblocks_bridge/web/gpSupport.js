// Handlers are ignored in gp.html when running as a Chrome App so must be added here:

function addGPHandlers() {
	var fileUploader = document.getElementById('FileUploader');
	fileUploader.onchange = function(evt) { uploadFiles(fileUploader.files); };
	var canvas = document.getElementById('canvas');
	canvas.oncontextmenu = function(evt) { evt.preventDefault(); }
}
addGPHandlers();


// GP variables

var GP = {
	events: [],
	isRetina: false,

	shadowColor: null,
	shadowOffset: 0,
	shadowBlur: 0,

	clipboard: null,
	clipboardBytes: [],
	droppedTextBytes: [],
	droppedFiles: [],
	lastSavedFileName: null,
	messages: [],

	lastCallId: 0,
	callQueue: [],
	apiResponses: {},

	delegateKeyboardEvents: false
};


// Mechanism for the HTML/JS world to be able to call GP functions.
// This is meant to make it possible to hybridize the IDE so we can start
// porting parts of it from GP to HTML/JS.
// API dispatcher: ide/MicroBlocksRuntime.gp → dispatchCall MicroBlocksAPI
// API docs: misc/API.md

GP.apiCall = function (endPoint, params, callback) {
	// example, get a random number from 10 to 20:
	// GP.apiCall('random', [10, 20], function (value) { console.log(value) });

	this.lastCallId = (this.lastCallId + 1) % 100000;

	if (typeof params == 'undefined') { params = ""; }
	if (typeof callback == 'undefined') { callback = ()=>{}; }

	this.callQueue.push([
		this.lastCallId,				// sequential ID
		endPoint,								// API endpoint selector
		callback,								// takes a param with the return value
		JSON.stringify(params)	// call params, JSON encoded
	]);
};

// Add the following to the meta tags in the header to suppress scaling of the GP canvas
// <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

// Clipboard Support
//	Chrome: works on HTTPS pages
//	Firefox: does not support clipboard.readText except in extensions
//	Safari: navigator.clipboard exists since 13.1 but is blocked for security reasons

GP.clipboard = document.createElement('textarea');
GP.clipboard.style.position = 'fixed';
GP.clipboard.style.left = '0px';
GP.clipboard.style.top = '0px';
GP.clipboard.style.width = '1px';
GP.clipboard.style.height = '1em';
GP.clipboard.style.border = '0';
GP.clipboard.style.padding = '0';
GP.clipboard.style.margin = '0';
GP.clipboard.style.outline = 'none';
GP.clipboard.style.opacity = '0';
document.body.appendChild(GP.clipboard);

function GP_focusClipboardForInput(selectAll, forceRefocus) {
	if (typeof selectAll === 'undefined') selectAll = true;
	if (typeof forceRefocus === 'undefined') forceRefocus = false;
	if (forceRefocus && (document.activeElement === GP.clipboard)) {
		GP.clipboard.blur();
	}
	try {
		GP.clipboard.focus({ preventScroll: true });
	} catch (err) {
		GP.clipboard.focus();
	}
	if (selectAll) GP.clipboard.select();
}

function GP_setInputPosition(x, y) {
	var canvas = document.getElementById('canvas');
	if (!canvas) return;

	var rect = canvas.getBoundingClientRect();
	if (GP.isRetina) {
		x = x / 2;
		y = y / 2;
	}

	GP.clipboard.style.left = (rect.left + x) + 'px';
	GP.clipboard.style.top = (rect.top + y) + 'px';
}

function isElectron() {
	return window.electronAPI !== undefined;
}

function setGPClipboard(s) {
	// Called by GP's setClipboard primitive

	GP.clipboardBytes = toUTF8Array(s);
	GP.clipboard.value = s;

	if ((typeof navigator.clipboard !== 'undefined') && (navigator.clipboard.writeText)) {
		navigator.clipboard.writeText(s).catch(() => {});
	} else {
		GP.clipboard.focus();
		GP.clipboard.select();
		try {
			document.execCommand('copy');
		} catch (err) {
			console.error('setGPClipboard failed', err);
		}
	}
}

async function readGPClipboard(s) {
	if ((typeof navigator.clipboard !== 'undefined') && (navigator.clipboard.readText)) {
		var s = await navigator.clipboard.readText().catch(() => {});
		if (s) GP.clipboard.value = s;
	} else {
		GP.clipboard.focus();
		GP.clipboard.select();
		try {
			document.execCommand('paste');
		} catch (err) {
			console.error('readGPClipboard failed', err);
		}
	}
	GP.clipboardBytes = toUTF8Array(GP.clipboard.value);
	return GP.clipboardBytes.length;
}

function toUTF8Array(str) {
	// Convert a Javascript string into an array of UTF8 bytes that can be read by GP.
	var utf8 = [];
	for (var i = 0; i < str.length; i++) {
		var charcode = str.charCodeAt(i);
		if (charcode < 0x80) utf8.push(charcode);
		else if (charcode < 0x800) {
			utf8.push(
				0xc0 | (charcode >> 6),
				0x80 | (charcode & 0x3f));
		}
		else if (charcode < 0x10000) {
			utf8.push(
				0xe0 | (charcode >> 12),
				0x80 | ((charcode >> 6) & 0x3f),
				0x80 | (charcode & 0x3f));
		} else if (charcode <= 0x10FFFF) {
			utf8.push(
				0xf0 | (charcode >> 18),
				0x80 | ((charcode >> 12) & 0x3f),
				0x80 | ((charcode >> 6) & 0x3f),
				0x80 | (charcode & 0x3f));
		}
	}
	return utf8;
}

function clipboardText() {
	return UTF8ArrayToString(GP.clipboardBytes);
}

// events

function initGPEventHandlers() {
	var MOUSE_DOWN = 1;
	var MOUSE_UP = 2;
	var MOUSE_MOVE = 3;
	var MOUSE_WHEEL = 4;
	var KEY_DOWN = 5;
	var KEY_UP = 6;
	var TEXTINPUT = 7;
	var TOUCH_DOWN = 8;
	var TOUCH_UP = 9;
	var TOUCH_MOVE = 10;
	var WINDOW_SHOWN = 11;

	function localPoint(x, y, yOffset) {
		var r = canvas.getBoundingClientRect();
		x = (x - r.left) | 0;
		y = (y - r.top) | 0;
		if (x < 0) x = 0;
		if (y < 0) y = 0;
		if (GP.isRetina) {
			x = 2 * x;
			y = 2 * y;
			yOffset = 2 * yOffset;
		}
		return [x, y - yOffset];
	}
	function modifierBits(evt) {
		var modifiers = ( // SDL modifier flags (for left-side versions of those keys)
		(evt.shiftKey ? 1 : 0) |
		(evt.ctrlKey ? 2 : 0) |
		(evt.altKey ? 4 : 0) |
		(evt.metaKey ? 8 : 0));
		return modifiers;
	}
	function keyEvent(evtType, evt) {
		var keyCode = evt.keyCode;
		var charCode = 0;
		if (evt.keyIdentifier) { // Safari
			if (evt.keyIdentifier.startsWith('U+')) {
				charCode = parseInt(evt.keyIdentifier.substring(2), 16);
			}
		} else if (evt.key && evt.key.charCodeAt && (evt.key.length == 1)) { // Chrome, Firefox
			if (evt.key.length == 1) {
				charCode = evt.key.charCodeAt(0);
			}
		}
		if (0 == charCode) {
			if (8 == evt.keyCode) charCode = 8; // backspace key
			if (9 == evt.keyCode) charCode = 9; // tab
			if (13 == evt.keyCode) charCode = 13; // enter
			if (27 == evt.keyCode) charCode = 27; // escape
			if (46 == evt.keyCode) charCode = 8; // map delete key to backspace
		}
		if ((65 <= charCode) && (charCode <= 90) && !evt.shiftKey) charCode += 32; // lowercase

		// make Firefox keycodes the same as Chrome/Safari:
		if ((59 == keyCode) && (59 == charCode)) keyCode = 186;
		if ((61 == keyCode) && (61 == charCode)) keyCode = 187;
		if ((173 == keyCode) && (45 == charCode)) keyCode = 189;
		if (224 == keyCode) keyCode = 91;

		var modifiers = ( // SDL modifier flags (for left-side versions of those keys)
			(evt.shiftKey ? 1 : 0) |
			(evt.ctrlKey ? 2 : 0) |
			(evt.altKey ? 4 : 0) |
			(evt.metaKey ? 8 : 0));

		return [evtType, keyCode, charCode, modifiers];
	}

	var canvas = document.getElementById('canvas');

	canvas.onmousedown = function(evt) {
		evt.preventDefault();
		var p = localPoint(evt.clientX, evt.clientY, 0);
		GP.events.push([MOUSE_DOWN, p[0], p[1], evt.button, modifierBits(evt)]);
	}
	canvas.onmouseup = function(evt) {
		var p = localPoint(evt.clientX, evt.clientY, 0);
		GP.events.push([MOUSE_UP, p[0], p[1], evt.button, modifierBits(evt)]);
	}
	canvas.onmousemove = function(evt) {
		var p = localPoint(evt.clientX, evt.clientY, 0);
		GP.events.push([MOUSE_MOVE, p[0], p[1]]);
	}
	document.onkeydown = function(evt) {
		if (GP.delegateKeyboardEvents) { return; }
		var key = evt.which;
		if (GP.isComposing || evt.isComposing || (229 == key)) return;
		if ((13 == key) && (/Android/i.test(navigator.userAgent))) {
			// On Android, generate text input events for entire string when the enter key is pressed
			var s = GP.clipboard.value;
			for (var i = 0; i < s.length; i++) GP.events.push([TEXTINPUT, s.charCodeAt(i)]);
			if (s.length == 0) GP.events.push([TEXTINPUT, 13]); // insert newline if no other characters
			GP.clipboard.value = '';
			evt.preventDefault();
			return;
		}
		var eventRecord = keyEvent(KEY_DOWN, evt);
		GP.events.push(eventRecord);
		// suppress browser's default behavior for various keys
		if ((9 == key) || (32 == key)) { // tab or space
			GP.events.push([TEXTINPUT, key]); // suppress, but do generate a textinput event
			evt.preventDefault();
		}
		if (8 == key) evt.preventDefault(); // backspace key
		if ((33 <= evt.which) && (evt.which <= 36)) evt.preventDefault(); // home, end, page up/down keys
		if ((37 <= evt.which) && (evt.which <= 40)) evt.preventDefault(); // arrow keys
		if (46 == key) evt.preventDefault(); // delete key
		if ((112 <= evt.which) && (evt.which <= 123)) evt.preventDefault(); // function keys
		if (evt.ctrlKey || evt.metaKey) {
			// special case for ctrl/cmd-C, ctrl/cmd-V, and ctrl/cmd-X  (copy, paste, cut)
			if ((67 == evt.keyCode) || (86 == evt.keyCode) || (88 == evt.keyCode)) {
				// push key down/up events for GP
				GP.events.push(keyEvent(KEY_DOWN, evt));
				GP.events.push(keyEvent(KEY_UP, evt));

				// focus and select clipboard element
				GP.clipboard.focus();
				GP.clipboard.select();
			}
		}
	}
	document.onkeyup = function(evt) {
		if (GP.isComposing || evt.isComposing || (229 == evt.which)) return;
		GP.events.push(keyEvent(KEY_UP, evt));
	}
	document.onkeypress = function(evt) {
		if (GP.isComposing || evt.isComposing) return;
		var charCode = evt.charCode;
		if (13 == charCode) return; // don't report a text input event for cr/enter
		if (evt.char && (evt.char.length == 1)) charCode = evt.char.codePointAt(0);
		GP.events.push([TEXTINPUT, charCode]);
	}

	// IME composition events
	document.addEventListener('compositionstart', function(evt) {
		GP.isComposing = true;
		GP.compositionText = '';
	});
	document.addEventListener('compositionupdate', function(evt) {
		GP.compositionText = evt.data;
	});
	document.addEventListener('compositionend', function(evt) {
		let composedText = evt.data || GP.compositionText || '';
		for (let ch of composedText) {
			GP.events.push([TEXTINPUT, ch.codePointAt(0)]);
		}
		GP.compositionText = '';
		GP.isComposing = false;
	});

	canvas.onwheel = function(evt) {
		if (evt.shiftKey || evt.ctrlKey) { return; } // default behavior (browser zoom)
		var dx = evt.wheelDeltaX;
		var dy = evt.wheelDeltaY;
		GP.events.push([MOUSE_WHEEL, dx, dy]);
		evt.preventDefault();
	}
	canvas.ontouchstart = function(evt) {
		var touch = evt.touches[0];
		if (touch) {
			// var button = (evt.touches.length == 2) ? 3 : 0; // did not work
			// Attempt to use two-finger touch for right button failed; always use left button.
			var button = 0;
			var p = localPoint(touch.clientX, touch.clientY, 10);
			GP.events.push([TOUCH_DOWN, p[0], p[1], button]);
		}
		evt.preventDefault();
	}
	canvas.ontouchmove = function(evt) {
		var touch = evt.touches[0];
		if (touch) {
			var p = localPoint(touch.clientX, touch.clientY, 10);
			GP.events.push([TOUCH_MOVE, p[0], p[1], 0]);
		}
		evt.preventDefault();
	}
	canvas.ontouchend = function(evt) {
		var touch = evt.changedTouches[0];
		if (touch) {
			var p = localPoint(touch.clientX, touch.clientY, 10);
			GP.events.push([TOUCH_UP, p[0], p[1], 0]);
		}
		evt.preventDefault();
	}
	canvas.ontouchcancel = function(evt) {
		GP.events.push([TOUCH_UP, 200, 200, 0]); // push a dummy touch_up event
	}
	window.onfocus = function(evt) {
		GP.events.push([WINDOW_SHOWN]);
	}
}
initGPEventHandlers();

function GP_backspace() {
	// Simulate the backspace/delete key on Android.
	var KEY_DOWN = 5;
	var KEY_UP = 6;
	GP.events.push([KEY_DOWN, 8, 8, 0]);
	GP.events.push([KEY_UP, 8, 8, 0]);
}

// drag-n-drop events

window.addEventListener(
	'dragover',
	function(evt) {
		evt.preventDefault();
	},
	false
);

window.addEventListener(
	'drop',
	function(evt) {
		evt.preventDefault();
		var files = evt.target.files || evt.dataTransfer.files;
		if (files && files.length) {
			uploadFiles(files);
		} else if (evt.dataTransfer) {
			// Dropping a text clipping or URL can be used as workaround for paste
			var s = evt.dataTransfer.getData('text/plain');
			if (s) GP.droppedTextBytes = toUTF8Array(s);
			var url = evt.dataTransfer.getData('URL');
			if (url) GP.droppedTextBytes = toUTF8Array(url + '\n');
		}
	},
	false
);

// message handling

function queueGPMessage(s) {
	// Queue a message that can be read by GP with the 'browserGetMessage' primitive
	// This mechanism is currently used by HTML buttons for 'go', 'stop', and 'see inside'.

	GP.messages.push(toUTF8Array(s));
}

function handleMessage(evt) {
	// Handle a message sent by the JavaScript postMessage() function.
	// This is used to control button visibility, to queue a message to GP
	// or to communicate with Boardie.

	var msg = evt.data;
	if (GP.boardie.isOpen && msg instanceof Uint8Array) {
		if (msg[0]) {
			// Boardie sent us bytes. Let's add them to the serial buffer.
			GP_serialInputBuffers.push(msg);
		}
	} else if (msg.constructor === Array) {
		switch (msg[0]) {
			case 'showButton':
				var btn = msg[1];
				if (btn) btn.style.display = 'inline';
				return;
			case 'hideButton':
				var btn = document.getElementById(msg[1]);
				if (btn) btn.style.display = 'none';
				return;
			case 'boardieKeyDown':
				GP.boardie.press(msg[1]);
				return;
			case 'boardieKeyUp':
				GP.boardie.unpress(msg[1]);
				return;
			case 'boardieGetFile':
				GP.boardie.files[msg[1]] = msg[2];
				return;
			case 'boardieDeleteFile':
				delete(GP.boardie.files[msg[1]]);
				return;
			case 'boardieSoundStart':
				boardie.element.querySelector('.audio').classList.add('--is-active');
				return;
			case 'boardieSoundStop':
				boardie.element.querySelector('.audio').classList.remove('--is-active');
				return;
			default:
				console.log('unrecognized message:', msg);
				return;
		}
	} else {
		queueGPMessage(msg);
	}
}

window.addEventListener("message", handleMessage, false);

// file upload support

function GP_UploadFiles(evt) {
	// Upload using "Upload" button
	var inp = document.getElementById('FileUploader'); // use the hidden file input element
	if (inp) inp.click();
}

function uploadFiles(files) {
	// Upload files. Initiated from either FileUploader click or drag-and-drop.

	function recordFile(f) {
		reader = new FileReader();
		reader.onloadend = function() {
			if (reader.result) {
				GP.droppedFiles.push({ name: toUTF8Array(f.name), contents: reader.result });
			}
			if (todo.length) recordFile(todo.shift());
		};
		reader.readAsArrayBuffer(f);
	}
	var todo = [];
	if (files && files.length) {
		for (var i = 0; i < files.length; i++) todo.push(files[i]);
		recordFile(todo.shift());
	}
}

// Canvas shadow effects

function setContextShadow(ctx) {
	if (!GP.shadowColor) return;
	ctx.shadowColor = GP.shadowColor;
	ctx.shadowOffsetX = GP.shadowOffsetX;
	ctx.shadowOffsetY = GP.shadowOffsetY;
	ctx.shadowBlur = GP.shadowBlur;
}

function setShadow(red, green, blue, alpha, offsetX, offsetY, blur) {
	GP.shadowColor = 'rgba(' + red + ', ' + green + ', ' + blue + ', ' + alpha + ')';
	GP.shadowOffsetX = offsetX;
	GP.shadowOffsetY = offsetY;
	GP.shadowBlur = blur;
}

function clearShadow() {
	GP.shadowColor = null;
	GP.shadowOffsetX = 0;
	GP.shadowOffsetY = 0;
	GP.shadowBlur = 0;
}

// stubs for unused GP primitives

function GP_audioContext() {}
function GP_startAudioInput(inputSampleCount, sampleRate) {}
function GP_stopAudioInput() {}
function GP_startAudioOutput(frameCount, isStereo) {}
function GP_stopAudioOutput() {}
function GP_toggleFullscreen() {}

// Boardie Support

// The IDE communicates with Boardie as if it were a serial port (i.e. using serial read/write)
// Boardie receives serial data from the IDE as a queue of Uint8 buffers.
// Boardie sends serial data to the IDE by pushing Uint8 buffers to GP_serialInputBuffers.

GP.boardie = {
	element: null,
	iframe: null,
	isOpen: false,
	position: null,
	reset: function () {
		win = this.iframe.contentWindow;
		win.postMessage(new Uint8Array([ 0xFA, 0x0F, 3 ]), '*'); // system reset w/ Boardie option
		ctx = win.document.querySelector('canvas').getContext('2d');
		ctx.fillStyle = "#000";
		ctx.fillRect(0, 0, 240, 240); // clear screen
		win.postMessage(new Uint8Array([ 0xFA, 0x05, 0 ]), '*'); // start all
	},
	buttonForCode: function (keyCode) {
		switch (parseInt(keyCode)) {
			case 37:
			case 65:
				return 'a';
			case 39:
			case 66:
				return 'b';
			case 84:
				return 'ab';
			default:
				return '';
		}
	},
	files: {},
	press: function (keyCode, andSendToBoard) {
		var button = this.buttonForCode(keyCode),
				element = this.element.querySelector(`[data-button="${button}"]`);
		if (element) { element.classList.add('--is-active'); }
		if (andSendToBoard) {
			this.iframe.contentWindow.postMessage(['keyDown', keyCode], '*');
		}
	},
	unpress: function (keyCode, andSendToBoard) {
		var button = this.buttonForCode(keyCode);
				element = this.element.querySelector(`[data-button="${button}"]`);
		if (element) { element.classList.remove('--is-active'); }
		if (andSendToBoard) {
			this.iframe.contentWindow.postMessage(['keyUp', keyCode], '*');
		}
	}
};

function GP_openBoardie() {
	var req = new XMLHttpRequest();
		boardie = GP.boardie;

	GP_closeSerialPort(); // close serial port if open
	GP.boardie.files = {}; // reset file cache

	req.open('GET', 'boardie/boardie.html');
	req.onreadystatechange = function () {
		if (req.readyState == 4 && req.status == 200) {
			boardie.element = document.createElement('div');
			boardie.element.classList.add('--can-drag-through');
			boardie.element.innerHTML = req.responseText;
			boardie.element.style.position = 'absolute';
			boardie.element.style.width = '272px';
			boardie.element.style.zIndex = 999;

			var ideCnv = document.getElementById('canvas');
			if (boardie.position &&
				(boardie.position.x <= ideCnv.clientWidth - 45) &&
				(boardie.position.y <= ideCnv.clientHeight - 45)) {
					boardie.element.style.left = boardie.position.x + 'px';
					boardie.element.style.top = boardie.position.y + 'px';
			} else {
				boardie.element.style.top = '70px';
				boardie.element.style.right = '34px';
			}
			boardie.element.style.cursor = 'grab';

			var isStandAlone = window.matchMedia('(display-mode: standalone)').matches;
			boardie.iframe = boardie.element.querySelector('iframe');
			if ((window.location.hostname == 'microblocks.fun') && !isStandAlone) {
				// Run Boardie from a separate domain to ensure it runs as an OOPIF
				boardie.iframe.src = 'https://boardie.microblocks.fun/vm.html';
			} else {
				// Load from source domain when not running from microblocks.fun
				// (e.g. when running as a stand-alone progressive web app).
				// Not the end of the world, but the UI will interfere with
				// time-sensitive threads, such as when making music
				boardie.iframe.src = 'boardie/vm.html';
			}

			boardie.element.onclick = function (evt) {
				if (!evt.target.closest('[data-button]')) {
					boardie.iframe.focus();
				}
			}

			document.body.append(boardie.element);

			makeDraggable(boardie.element);

			boardie.element.querySelectorAll('[data-button]').forEach(
				button => {
					button.addEventListener('keydown', (evt) => {
						boardie.press(evt.keyCode, true);
						boardie.iframe.focus();
					});
				}
			);

			boardie.iframe.contentWindow.addEventListener('click', (event) => {
				boardie.element.classList.add('--is-active');
			});

			boardie.isOpen = true;
			GP.apiCall('ide.updateConnection');
		}
	};

	req.send();
};

function focusDetection (elementSelector) {
	document.addEventListener('click', (event) => {
		var element = document.querySelector(elementSelector);
		if (element) {
			if (event.target.closest('.boardie')) {
				if (!element.classList.contains('--is-active')) {
					element.classList.add('--is-active');
				}
			} else {
				element.classList.remove('--is-active');
			}
		}
	});
};
focusDetection('.boardie');

function GP_closeBoardie() {
	if (GP.boardie.element) {
		document.body.removeChild(GP.boardie.element);
		GP.boardie.element = null;
		GP.boardie.iframe = null;
		GP.boardie.isOpen = false;
		IDE.board.connected = false;
		GP.apiCall('ide.updateConnection');
	}
}

// Serial Ports (supported in Chrome OS and Chromium-based browsers only)
// Only one serial port can be open at a time.

function hasChromeSerial() {
	return ((typeof chrome != 'undefined') && (typeof chrome.serial != 'undefined'))
}

function hasWebSerial() {
	return (typeof navigator.serial != 'undefined');
}

function hasWebBluetooth() {
	return (typeof navigator.bluetooth != 'undefined');
}

function webBluetoothConnected() {
	return hasWebBluetooth() && bleSerial.isConnected();
}

// WebSerial support for Chrome browser (navigator.serial API)

GP_webSerialPort = null;
GP_webSerialReader = null;

function webSerialIsConnected() {
	return !(!GP_webSerialPort || !GP_webSerialReader);
}

async function webSerialConnect() {
	// Prompt user to choose a serial port and open the one selected.

	var vendorIDs = [
		{ usbVendorId: 0x0403},		// FTDI
		{ usbVendorId: 0x0d28},		// micro:bit, Calliope
		{ usbVendorId: 0x10c4},		// Silicon Laboratories, Inc. (CP210x)
		{ usbVendorId: 0x1a86},		// CH340
		{ usbVendorId: 0x239a},		// AdaFruit
		{ usbVendorId: 0x2a03},		// Arduino
		{ usbVendorId: 0x2341},		// Arduino MKR Zero
		{ usbVendorId: 0x03eb},		// Atmel Corporation
		{ usbVendorId: 0x1366},		// SEGGER Calliope mini
		{ usbVendorId: 0x16c0},		// Teensy
		{ usbVendorId: 0x2E8A},		// Raspberry Pi Pico RP2040
		{ usbVendorId: 0x303a},		// Espressif USB JTAG/serial debug unit
		{ usbVendorId: 0x0483},		// STMicroelectronics
		{ usbVendorId: 0x1B9F, usbProductId: 0xF301},	// GHI/DUELink, MicroBlocks PID
		{ usbVendorId: 0x1B4F},		// XRP
		{ usbVendorId: 0x2886},		// Seeed
		{ usbVendorId: 0x0005},		// HC-05
	];
	webSerialDisconnect();
	GP_webSerialPort = await navigator.serial.requestPort({filters: vendorIDs}).catch((e) => { console.log(e); });
	if (!GP_webSerialPort) return; // no serial port selected
	await GP_webSerialPort.open({ baudRate: 115200 }).catch((e) => { window.alert(e); return; });
	GP_webSerialReader = await GP_webSerialPort.readable.getReader();
	GP.apiCall('ide.updateConnection');
	webSerialReadLoop();
}

async function webSerialDisconnect() {
	if (GP_webSerialReader) await GP_webSerialReader.cancel().catch(() => {});
	if (GP_webSerialPort) await GP_webSerialPort.close().catch(() => {});
	GP_webSerialReader = null;
	GP_webSerialPort = null;
	GP.apiCall('ide.updateConnection');
}

async function webSerialReadLoop() {
	try {
		while (true) {
			var { value, done } = await GP_webSerialReader.read();
			if (value) {
				GP_serialInputBuffers.push(value);
			}
			if (done) { // happens when GP_webSerialReader.cancel() is called by disconnect
				GP_webSerialReader.releaseLock();
				return;
			}
		}
	} catch (e) { // happens when board is unplugged
		console.log(e);
		await GP_webSerialPort.close().catch(() => {});
		GP_webSerialPort = null;
		GP_webSerialReader = null;
		console.log('Connection closed.');
		GP.apiCall('ide.updateConnection');
	}
}

function webSerialWrite(data) {
	if (!GP_webSerialPort || !GP_webSerialPort.writable) return 0;  // port not open
	const w = GP_webSerialPort.writable.getWriter();
	w.write(data.buffer);
	w.releaseLock();
	return data.buffer.byteLength;
}

// Variables used by Chromebook App Serial (chrome.serial API)

GP_serialPortNames = [];
GP_serialPortID = -1;
GP_serialInputBuffers = [];  // a list of Uint8 arrays
GP_serialPortListenersAdded = false;

// Serial support for both WebSerial and Chromebook App

function GP_getSerialPorts() {
	// Request an update to the serial port list, GP_serialPortNames. Since this call
	// is asynchronous, the result is not available in GP_serialPortNames immediately.
	// The caller should call this, wait a bit, then read GP_serialPortNames.

	function listPorts(ports) {
		GP_serialPortNames = [];
		for (var i = 0; i < ports.length; i++) {
			if (!ports[i].path.startsWith('/dev/ttyMSM')) {
				GP_serialPortNames.push(toUTF8Array(ports[i].path));
			}
		}
	}
	if (hasChromeSerial()) chrome.serial.getDevices(listPorts);
}

function GP_openSerialPort(id, path, baud) {
	function serialPortError(info) {
		console.log('Serial port error: ' + info.error);
		GP_closeSerialPort();
	}
	function serialPortDataReceived(info) {
		GP_serialInputBuffers.push(new Uint8Array(info.data));
	}
	function portOpened(connectionInfo) {
		if (!connectionInfo || chrome.runtime.lastError) {
			var reason = '';
			if (chrome.runtime.lastError) reason = chrome.runtime.lastError.message
			console.log('Port open failed ' + reason);
			GP_serialPortID = -1;
			return; // failed to open port
		}
		GP_serialPortID = connectionInfo.connectionId;
		GP_serialInputBuffers = [];
		if (!GP_serialPortListenersAdded) {
			// Listeners only need to be added once.
			chrome.serial.onReceiveError.addListener(serialPortError);
			chrome.serial.onReceive.addListener(serialPortDataReceived);
			GP_serialPortListenersAdded = true;
		}
	}
	if (GP.boardie.isOpen) { return 1; }
	if (hasWebBluetooth() && (path == 'webBLE')) {
		bleSerial.connect();
	} else if (hasWebSerial()) {
		webSerialConnect();
	} else if (hasChromeSerial()) {
		if (GP_serialPortID >= 0) return 1; // already open (not an error)
		chrome.serial.connect(path, {bitrate: baud}, portOpened)
	}
	return 1; // connect is asynchronous, but assume it will succeed
}

function GP_isOpenSerialPort() {
	if (GP.boardie.isOpen) { return true; }
	if (webBluetoothConnected()) { return true; }
	if (hasWebSerial()) return webSerialIsConnected();
	if (hasChromeSerial()) return (GP_serialPortID >= 0);
	return false;
}

function GP_closeSerialPort() {
	if (GP.boardie.isOpen) {
		GP_closeBoardie();
	} else if (webBluetoothConnected()) {
		bleSerial.disconnect();
	} else if (hasWebSerial()) {
		webSerialDisconnect();
	} else if (GP_serialPortID > 0) {
		function portClosed(ignored) { }
		chrome.serial.disconnect(GP_serialPortID, portClosed);
	}
	GP_serialPortID = -1;
	GP_serialInputBuffers = [];
}

function GP_readSerialPort(maxBytes) {
	if (GP_serialInputBuffers.length == 0) {
		return new Uint8Array(new ArrayBuffer(0)); // no data available
	}
	var count = 0;
	for (var i = 0; i < GP_serialInputBuffers.length; i++) {
		count += GP_serialInputBuffers[i].byteLength;
	}
	var result = new Uint8Array(new ArrayBuffer(count));
	var dst = 0;
	for (var i = 0; i < GP_serialInputBuffers.length; i++) {
		var buf = GP_serialInputBuffers[i];
		result.set(GP_serialInputBuffers[i], dst);
		dst += GP_serialInputBuffers[i].byteLength;
	}
	if (result.byteLength <= maxBytes) {
		GP_serialInputBuffers = [];
	} else {
		GP_serialInputBuffers = [result.slice(maxBytes)];
		result = result.slice(0, maxBytes);
	}
	return result;
}

function GP_writeSerialPort(data) {
	if (GP.boardie.isOpen) {
		GP.boardie.iframe.contentWindow.postMessage(data, '*');
		return data.buffer.byteLength;
	} else if (webBluetoothConnected()) {
		return bleSerial.write_data(data);
	} else if (hasWebSerial()) {
		return webSerialWrite(data);
	} else if (hasChromeSerial()) {
		function dataSent(ignored) { }
		if (GP_serialPortID < 0) return -1; // port not open
		chrome.serial.send(GP_serialPortID, data.buffer, dataSent);
		return data.buffer.byteLength;
	}
	return 0;
}

async function GP_setSerialPortDTR(flag) {
	if (GP.boardie_IsOpen) {
		return; // do nothing
	} else if (hasWebSerial()) {
		if (!GP_webSerialPort) return; // port not open
		await GP_webSerialPort.setSignals({ dtr: flag, dataTerminalReady: flag }).catch(() => {});
	} else if (hasChromeSerial()) {
		function ignore(result) {}
		flag = (flag) ? true : false;
		chrome.serial.setControlSignals(GP_serialPortID, { dtr: flag }, ignore);
	}
}

async function GP_setSerialPortRTS(flag) {
	if (GP.boardie_IsOpen) {
		return; // do nothing
	} else if (hasWebSerial()) {
		if (!GP_webSerialPort) return; // port not open
		await GP_webSerialPort.setSignals({ rts: flag, requestToSend: flag }).catch(() => {});
	} else if (hasChromeSerial()) {
		function ignore(result) {}
		flag = (flag) ? true : false;
		chrome.serial.setControlSignals(GP_serialPortID, { rts: flag }, ignore);
	}
}

async function GP_setSerialPortDTRandRTS(dtrFlag, rtsFlag) {
	if (hasWebSerial()) {
		if (!GP_webSerialPort) return; // port not open
		await GP_webSerialPort.setSignals(
			{ dtr: dtrFlag, dataTerminalReady: dtrFlag, rts: rtsFlag, requestToSend: rtsFlag }
		).catch(() => {});
	} else if (hasChromeSerial()) {
		function ignore(result) {}
		flag = (flag) ? true : false;
		chrome.serial.setControlSignals(GP_serialPortID, { dtr: dtrFlag, rts: rtsFlag }, ignore);
	}
}

// Support for Web Bluetooth

// MicroBlocks UUIDs:
const MICROBLOCKS_SERVICE_UUID = 'bb37a001-b922-4018-8e74-e14824b3a638'
const MICROBLOCKS_RX_CHAR_UUID = 'bb37a002-b922-4018-8e74-e14824b3a638' // board receive characteristic
const MICROBLOCKS_TX_CHAR_UUID = 'bb37a003-b922-4018-8e74-e14824b3a638' // board transmit characteristic

const BLE_PACKET_LEN = 240; // Max BLE attribute length is 512 but 240 gives best performance

class NimBLESerial {
	// Device to communicate over BLE using the Nordic Semiconductor UART service

	constructor() {
		this.device = undefined;
		this.service = undefined;
		this.rx_char = undefined;
		this.connected = false;
		this.sendInProgress = false;
	}

	handle_disconnected(event) {
		console.log("BLE disconnected");
		this.rx_char = undefined;
		this.connected = false;
		this.sendInProgress = false;
	}

	handle_read(event) {
		let data = new Uint8Array(event.target.value.buffer);
		GP_serialInputBuffers.push(data);
	}

	async connect() {
		// Connect to a microcontroller
		this.device = await navigator.bluetooth.requestDevice({
			filters: [{ services: [MICROBLOCKS_SERVICE_UUID] }]
		})
		this.device.addEventListener('gattserverdisconnected', this.handle_disconnected.bind(this));
		const server = await this.device.gatt.connect();
		this.service = await server.getPrimaryService(MICROBLOCKS_SERVICE_UUID);
		const tx_char = await this.service.getCharacteristic(MICROBLOCKS_TX_CHAR_UUID);
		this.rx_char = await this.service.getCharacteristic(MICROBLOCKS_RX_CHAR_UUID);
		await tx_char.startNotifications();
		// bind overrides the default this=tx_char to this=the NimBLESerial
		tx_char.addEventListener("characteristicvaluechanged", this.handle_read.bind(this));
		this.connected = true;
		this.sendInProgress = false;
		console.log("BLE connected");
		GP.apiCall('ide.updateConnection');
	}

	disconnect() {
		if (this.device != undefined) {
			this.device.gatt.disconnect();
		}
		GP.apiCall('ide.updateConnection');
	}

	isConnected() {
		return this.connected;
	}

	write_data(data) {
		// Write the given data (a Uint8Array) and return the number of bytes written.

		if ((this.rx_char == undefined) || !this.connected) {
			console.log("Not connected");
			return 0;
		}
		if (this.sendInProgress) {
			console.log("Send in progress in gpSupport.js write_data()");
			return 0;
		}
		let byteCount = (data.length > BLE_PACKET_LEN) ? BLE_PACKET_LEN : data.length;
		this.async_write_data(data.subarray(0, byteCount));
		return byteCount;
 	}

	async async_write_data(data) {
		if (this.rx_char == undefined) return;
		this.sendInProgress = true;
		try {
			await this.rx_char.writeValueWithoutResponse(data);
		} catch (error) {
			// print the error; give up if BLE has been disconnected
			console.log("BLE write failed:\n ", error);
		}
		this.sendInProgress = false;
	}
}

const bleSerial = new NimBLESerial();

// File read/write

async function GP_ReadFile(ext) {
	// Upload using Native File API.

	if (GP_isMobile()) {
		GP_UploadFiles();
	} else if (isElectron()) {
		const result = await window.electronAPI.openFile();
		GP.droppedFiles.push({ name: toUTF8Array(result.filePath), contents: result.content });
	} else if (typeof window.showOpenFilePicker != 'undefined') { // Native Filesystem API
		var options = {};
		if ('' != ext) {
			options = { types: [{ description: 'MicroBlocks', accept: { 'text/plain': ['.' + ext] }}] };
		}
		const files = await window.showOpenFilePicker(options).catch((e) => { console.log(e); });
		if (typeof files === 'undefined') { console.log('No file selected.'); return; }
		const file = await files[0].getFile();
		const contents = await file.arrayBuffer();
		GP.droppedFiles.push({ name: toUTF8Array(file.name), contents: contents });
	} else {
		GP_UploadFiles();
		return;
	}
}

function download(filename, text) {
	// from https://stackoverflow.com/questions/2897619/using-html5-javascript-to-generate-and-save-a-file

	var pom = document.createElement('a');
	pom.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
	pom.setAttribute('download', filename);

	if (document.createEvent) {
		var event = document.createEvent('MouseEvents');
		event.initEvent('click', true, true);
		pom.dispatchEvent(event);
	} else {
		pom.click();
	}
}

async function GP_writeFile(data, fName, id) {
	// Write the given data to the given file. fName should include an extension.
	// id is hint for the operation type (e.g. 'project' for saving a project file).
	// The browser remembers the folder for the last save with that id.

	if (fName.length == 0) fName = 'Untitled';

	if (isElectron()) {
		const isBinary = fName.endsWith('.hex') || fName.endsWith('.uf2');
		const savedFilePath = await window.electronAPI.saveFile(fName, isBinary, data);
		const i = savedFilePath.lastIndexOf('/');
		GP.lastSavedFileName = (i >= 0) ? savedFilePath.substr(i + 1) : savedFilePath;
	} else if (typeof window.showSaveFilePicker != 'undefined') { // Native Filesystem API
		let ext = '';
		const i = fName.lastIndexOf('.');
		if (i >= 0) {
			ext = fName.substr(i + 1);
			fName = fName.substr(0, i);
		}

		options = { suggestedName: fName + '.' + ext, id: id };
		if ('' != ext) {
			if ('.' != ext[0]) ext = '.' + ext;
			if (('.hex' == ext) || ('.uf2' == ext)) {
				options.types = [{ accept: { 'application/octet-stream': [ext] } }];
			} else {
				options.types = [{ accept: { 'text/plain': [ext] } }];
			}
		}

		const fileHandle = await window.showSaveFilePicker(options).catch((e) => { console.log(e); });
		if (!fileHandle) {
			GP.lastSavedFileName = '_no_file_selected_';
			return; // no file selected
		}
		const writable = await fileHandle.createWritable();
		await writable.write(new Blob([data]));
		await writable.close().catch(() => {});
		GP.lastSavedFileName = fileHandle.name;
	} else {
		saveAs(new Blob([data]), fName);
		GP.lastSavedFileName = fName;
	}
}

// Floating Keyboard Input dialog for mobile browsers
// Adapted from Zhongrui You's CoCube MicroBlocks app. Thanks!

function GP_isMobile() {
	var isKindle = /Kindle|Silk|KFAPW|KFARWI|KFASWI|KFFOWI|KFJW|KFMEWI|KFOT|KFS‌​AW|KFSOWI|KFTBW|KFTH‌​W|KFTT|WFFOWI/i.test(navigator.userAgent);
	var isOtherMobile = /Android|webOS|iPhone|iPad|iPod|CriOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
	return isKindle || isOtherMobile;
}

let GP_floatingContainer = null;
let GP_floatingInput = null;
let GP_isFloatingInputActive = false;

// 创建浮动输入 UI
function GP_createFloatingUI() {
	if (GP_floatingContainer) return;

	// 检测系统语言
	const isChinese = navigator.language.toLowerCase().startsWith('zh');
	const labels = {
		placeholder: isChinese ? '请输入...' : 'Enter text...',
		confirm: isChinese ? '确认' : 'Confirm',
		cancel: isChinese ? '取消' : 'Cancel'
	};

	// 外层遮罩
	const wrapper = document.createElement('div');
	wrapper.id = 'floating-input-wrapper';
	wrapper.style.cssText = `
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background: rgba(0, 0, 0, 0.5);
		z-index: 999999;
		display: none;
		align-items: center;
		justify-content: center;
	`;

	// 输入框容器
	const container = document.createElement('div');
	container.style.cssText = `
		background: white;
		border-radius: 12px;
		padding: 20px;
		box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
		min-width: 320px;
		max-width: 90vw;
		animation: slideUp 0.3s ease-out;
	`;

	// 输入框
	const input = document.createElement('input');
	input.type = 'text';
	input.placeholder = labels.placeholder;
	input.style.cssText = `
		width: 100%;
		padding: 12px 16px;
		font-size: 16px;
		border: 2px solid #e0e0e0;
		border-radius: 8px;
		box-sizing: border-box;
		outline: none;
		-webkit-appearance: none;
	`;

	// 按钮容器
	const btnContainer = document.createElement('div');
	btnContainer.style.cssText = `
		display: flex;
		gap: 12px;
		margin-top: 16px;
	`;

	// 取消按钮
	const cancelBtn = document.createElement('button');
	cancelBtn.textContent = labels.cancel;
	cancelBtn.style.cssText = `
		flex: 1;
		padding: 12px;
		font-size: 16px;
		background: #f5f5f5;
		color: #666;
		border: none;
		border-radius: 8px;
		font-weight: 500;
		-webkit-tap-highlight-color: transparent;
	`;

	// 确认按钮
	const confirmBtn = document.createElement('button');
	confirmBtn.textContent = labels.confirm;
	confirmBtn.style.cssText = `
		flex: 1;
		padding: 12px;
		font-size: 16px;
		background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
		color: white;
		border: none;
		border-radius: 8px;
		font-weight: 500;
		-webkit-tap-highlight-color: transparent;
	`;

	// 添加动画
	const style = document.createElement('style');
	style.textContent = `
		@keyframes slideUp {
			from { opacity: 0; transform: translateY(30px); }
			to { opacity: 1; transform: translateY(0); }
		}
	`;
	document.head.appendChild(style);

	// 组装 DOM
	btnContainer.appendChild(cancelBtn);
	btnContainer.appendChild(confirmBtn);
	container.appendChild(input);
	container.appendChild(btnContainer);
	wrapper.appendChild(container);
	document.body.appendChild(wrapper);

	GP_floatingContainer = wrapper;
	GP_floatingInput = input;

	// 绑定事件
	confirmBtn.onclick = () => GP_confirmFloatingInput();
	cancelBtn.onclick = () => GP_cancelFloatingInput();

	// 修复退格键问题 - 阻止事件冒泡
	input.onkeydown = (e) => {
		// 阻止事件冒泡到 document,避免被全局键盘处理器拦截
		e.stopPropagation();

		if (e.key === 'Enter') {
			e.preventDefault();
			GP_confirmFloatingInput();
		}
		if (e.key === 'Escape') {
			e.preventDefault();
			GP_cancelFloatingInput();
		}
		// 其他按键(包括退格)允许默认行为
	};

	// stop propagation of other keyboard input events
	input.addEventListener('keypress', (e) => { e.stopPropagation() });
	input.addEventListener('keyup', (e) => { e.stopPropagation() });
	input.addEventListener('compositionstart', (e) => { e.stopPropagation() });
	input.addEventListener('compositionupdate', (e) => { e.stopPropagation() });
	input.addEventListener('compositionend', (e) => { e.stopPropagation() });

	// 防止点击遮罩关闭
	wrapper.onclick = (e) => {
		if (e.target === wrapper) GP_cancelFloatingInput();
	};

	// 防止按钮事件冒泡
	confirmBtn.onclick = (e) => {
		e.stopPropagation();
		GP_confirmFloatingInput();
	};
	cancelBtn.onclick = (e) => {
		e.stopPropagation();
		GP_cancelFloatingInput();
	};
}

// 显示浮动输入框
function GP_showFloatingInput() {
	if (!GP_isMobile()) {
		GP.clipboard.value = GP.defaultEditText || '';
		// Delay focus to next animation frame so all setInputPosition calls
		// complete before focus triggers IME candidate window positioning.
		// Fixes Edge/Chromium not picking up new textarea position on focus.
		if (GP._pendingFocusRAF) cancelAnimationFrame(GP._pendingFocusRAF);
		GP._pendingFocusRAF = requestAnimationFrame(function() {
			GP._pendingFocusRAF = null;
			GP_focusClipboardForInput(true, true);
		});
		return;
	}
	if (GP_isFloatingInputActive) return;

	GP_createFloatingUI();

	// 显示容器
	GP_floatingContainer.style.display = 'flex';
	if (!GP.defaultEditText) GP.defaultEditText = '';
	GP_floatingInput.value = GP.defaultEditText;

	// 标记为激活状态
	GP_isFloatingInputActive = true;

	// 延迟聚焦,确保键盘正确弹出
	setTimeout(() => {
		GP_floatingInput.focus();
		GP_floatingInput.select();

		// iOS 额外触发
		if (/iPad|iPhone|iPod/.test(navigator.userAgent)) {
			GP_floatingInput.click();
		}
	}, 100);

	// 阻止原生 clipboard 获得焦点
	GP.clipboard.blur();
}

// 确认输入
function GP_confirmFloatingInput() {
	if (!GP_isFloatingInputActive) return;

	const value = GP_floatingInput.value;

	// 🔑 关键修改:完全覆盖,而非追加
	// 1. 先清空原有内容(发送退格键删除所有字符)

	const KEY_DOWN = 5;
	const KEY_UP = 6;

	// 方案1: 发送 Ctrl+A 全选 + Delete
	// 模拟 Ctrl+A (全选)
	GP.events.push([KEY_DOWN, 17, 0, 2]); // Ctrl down (keyCode=17, modifiers=2)
	GP.events.push([KEY_DOWN, 65, 97, 2]); // A down (keyCode=65, charCode=97)
	GP.events.push([KEY_UP, 65, 97, 2]);   // A up
	GP.events.push([KEY_UP, 17, 0, 2]);    // Ctrl up

	// 模拟 Delete/Backspace
	GP.events.push([KEY_DOWN, 8, 8, 0]);   // Backspace down
	GP.events.push([KEY_UP, 8, 8, 0]);     // Backspace up


	// 2. 写入新内容
	GP.clipboard.value = value;

	// 3. 生成新内容的 textinput 事件
	const TEXTINPUT = 7;
	if (/Android/i.test(navigator.userAgent)) {
		// Android 特殊处理
		for (let i = 0; i < value.length; i++) {
			GP.events.push([TEXTINPUT, value.charCodeAt(i)]);
		}
		if (value.length === 0) {
			GP.events.push([TEXTINPUT, 13]); // 空字符串插入换行符
		}
	} else {
		// 其他平台
		for (let ch of value) {
			GP.events.push([TEXTINPUT, ch.codePointAt(0)]);
		}
	}

	GP_hideFloatingInput();
}
// 取消输入
function GP_cancelFloatingInput() {
	if (!GP_isFloatingInputActive) return;
	GP_hideFloatingInput();
}

// 隐藏浮动输入框
function GP_hideFloatingInput() {
	if (!GP_isMobile()) {
		if (GP._pendingFocusRAF) {
			cancelAnimationFrame(GP._pendingFocusRAF);
			GP._pendingFocusRAF = null;
		}
		GP.clipboard.blur();
		document.getElementById('canvas').focus();
		return;
	}
	if (!GP_floatingContainer) return;

	GP_floatingContainer.style.display = 'none';
	GP_floatingInput.blur();
	GP_isFloatingInputActive = false;

	// 将焦点返回给 canvas
	document.getElementById('canvas').focus();
}

// warn before leaving page

window.onbeforeunload = function() {
	return "Leave this page? (changes will be lost)";
};

// progressive web app service worker

window.onload = function() {
	if ('serviceWorker' in navigator) {
		// UNO Q: local server assets, service worker registration disabled.
	}
}
